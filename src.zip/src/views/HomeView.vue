<script setup>
import LandingComponent from "@/components/LandingComponent.vue";
</script>
<template>
  <div>
    <LandingComponent/>
  </div>
</template>
<style>
</style>
